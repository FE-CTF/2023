#!/usr/bin/env python3
import ctypes
import os
import argparse
import struct
import fcntl
import subprocess
import socket
import signal
import select
import sys
import hashlib
import logging
import time

toplevel_log = logging.getLogger("ctfvpn")

libc = ctypes.CDLL("libc.so.6")
libc.unshare.restype = ctypes.c_int
libc.unshare.argtypes = [ctypes.c_int]

CLONE_NEWNS = 0x00020000
CLONE_NEWUSER = 0x10000000
CLONE_NEWPID = 0x20000000
CLONE_NEWNET = 0x40000000 

TUNSETIFF = 0x400454ca
IFF_TAP = 0x0002
IFF_NO_PI = 0x1000

def open_tap_device(ifname, up=True, address=None):
    tap = open("/dev/net/tun", "w+b", buffering=0)
    ifr = struct.pack('16sH', ifname.encode("ascii"), IFF_TAP | IFF_NO_PI)
    fcntl.ioctl(tap.fileno(), TUNSETIFF, ifr)
    if up:
        subprocess.check_call(["/bin/ip", "link", "set", "lo", "up"])
        subprocess.check_call(["/bin/ip", "link", "set", ifname, "up"])
    if address:
        subprocess.check_call(["/bin/ip", "addr", "add", address, "dev", ifname])
    return tap

def namespace_sandbox(args, func, *a, **kw):
    log = toplevel_log.getChild("sandbox")

    old_uid, old_gid = os.getuid(), os.getgid()

    # 1. unshare namespace: mnt, pid, net, and optionally user
    log.info("Setting up namespace sandbox")
    flags = CLONE_NEWNET | CLONE_NEWNS | CLONE_NEWPID
    if args.unshare_user: flags |= CLONE_NEWUSER
    assert libc.unshare(flags) == 0, "Could not unshare namespaces"

    if args.unshare_user:
        # 2a. Configure user namespace
        log.info(f"Configuring user namespace, mapping root to {old_uid}")
        with open("/proc/self/uid_map", "w") as f: f.write(f"0 {old_uid} 1")
        with open("/proc/self/setgroups", "w") as f: f.write(f"deny")
        with open("/proc/self/gid_map", "w") as f: f.write(f"0 {old_gid} 1")

    # 2b. Enter pid namespace
    pid = os.fork()
    if pid == 0:
        # Child process, pid 1(init) in pid namespace
        try:
            log.debug(f"Entered pid namespace")

            # 4. Mount /proc to reflect correct process namespace
            subprocess.check_call(["/bin/mount", "--make-rprivate", "/"])
            subprocess.check_call(["/bin/mount", "-t", "proc", "proc", "/proc"])

            # 5. Call inner function
            log.debug(f"Calling inner function")
            func(*a, **kw)
            log.debug("inner func returned")
        except (EOFError, TimeoutError) as e:
            log.info(f"Exception in pid 1: {repr(e)}")
        except Exception as e:
            log.exception(f"Exception in pid 1: {repr(e)}")
        finally:
            # 6. Flush stdio and exit without cleanup
            sys.stderr.flush()
            sys.stdout.flush()
            os._exit(0)

    # 3. Wait for child / pid 1 / process namespace to die.
    log.info(f"{os.getpid()}: Waiting for child {pid}")
    pid, status = os.waitpid(pid, 0)
    log.info(f"{os.getpid()}: Child {pid} exited with status {status}")

def recvn(sock, n):
    data = b''
    while len(data) < n:
        chunk = sock.recv(n - len(data))
        if not chunk: raise EOFError
        data += chunk
    return data

def recv_msg(client):
    channel, size = struct.unpack("!HH", recvn(client, 4))
    return channel, recvn(client, size)

def send_msg(client, channel, data):
    client.sendall(struct.pack("!HH", channel, len(data)) + data)

def do_pow_server(args, client):
    log = toplevel_log.getChild("pow")
    # Arm POW timeout alarm
    signal.alarm(args.pow_timeout)

    # Do proof of work
    pow_prefix = os.urandom(32)
    pow_challenge = struct.pack("!L32s", args.pow_bits, pow_prefix)

    log.info(f"Sending challenge {pow_prefix.hex()} bits {args.pow_bits}")
    send_msg(client, args.pow_channel, pow_challenge)

    channel, pow_solution = recv_msg(client)
    assert channel == args.pow_channel
    assert len(pow_solution) == 32
    digest = hashlib.sha256(pow_prefix + pow_solution).digest()
    number = int.from_bytes(digest, byteorder="big", signed=False)
    assert number >> (256 - args.pow_bits) == 0

    log.info(f"Got valid solution {pow_solution.hex()}")

    signal.alarm(0)

def do_pow_client(args, client):
    log = toplevel_log.getChild("pow")
    pow_channel, pow_challenge = recv_msg(client)
    pow_bits, pow_prefix = struct.unpack("!L32s", pow_challenge)
    log.info(f"Prefix {pow_prefix.hex()} bits {pow_bits}")
    i = 0
    last_update = 0
    while True:
        i += 1
        if i % 10000 == 0:
            if last_update + 1 < time.time():
                log.debug(f"{i}/{1 << pow_bits}")
                last_update = time.time()
        pow_solution = os.urandom(32)
        digest = hashlib.sha256(pow_prefix + pow_solution).digest()
        number = int.from_bytes(digest, byteorder="big", signed=False)
        if number >> (256 - pow_bits) == 0:
            log.info(f"Found {pow_solution.hex()} after {i} iterations")
            send_msg(client, pow_channel, pow_solution)
            break

def shovel(client, wr_channels, rd_channels, until=lambda: True):
    log = toplevel_log.getChild("shovel")
    while not until():
        rfds = list(wr_channels.keys()) + [client]
        select_res = select.select(rfds, [], [], 1)
        log.debug(f"{select_res=}")
        for rfd in select_res[0]:
            if rfd == client:
                channel, data = recv_msg(client)
                log.debug(f"Got message for channel {channel} size {len(data)}")
                if channel in rd_channels:
                    rd_channels[channel].write(data)
                    rd_channels[channel].flush()
                else:
                    log.info(f"Got message on unknown channel {channel} size {len(data)}")
            elif rfd in wr_channels:
                log.debug(f"Sending data from {rfd} to channel {wr_channels[rfd]}")
                data = rfd.read(4096)
                send_msg(client, wr_channels[rfd], data)
                if not data:
                    log.debug(f"{rfd} read returned no data. removing from wr_channels")
                    del wr_channels[rfd]

            else:
                log.debug(f"Unknown rfd {rfd}")


def alarm_handler(signum, stack):
    log = toplevel_log.getChild("alarm")
    log.error("Got SIGALRM, terminating")
    raise TimeoutError("Alarm clock")

def handle_incomming_connection(args, client, address):
    signal.signal(signal.SIGALRM, alarm_handler)

    log = toplevel_log.getChild("connection")
    log.info(f"Handling connection from {address}")

    # Do POW
    do_pow_server(args, client)

    # Arm challenge timeout
    log.info("Starting challenge")
    signal.alarm(args.timeout)

    # Open and configure tap device
    log.info("Configuring network")
    tap = open_tap_device(args.network_interface, address=args.network_address)

    # Start child process
    log.info("Starting challenge subprocess")
    process = subprocess.Popen(
        args.command,
        shell=args.shell,
        start_new_session=args.new_session,
        bufsize=0,
        stdin=subprocess.PIPE if args.stdin_channel != None else subprocess.DEVNULL,
        stdout=subprocess.PIPE if args.stdout_channel != None else subprocess.DEVNULL,
        stderr=subprocess.PIPE if args.stderr_channel != None else subprocess.DEVNULL,
    )

    # Tunnel network traffic and stdio if enabled.
    log.debug(f"Shovling network traffic on {args.network_channel}")
    wr_channels = {tap: args.network_channel}
    rd_channels = {args.network_channel: tap}
    if args.stdin_channel != None:
        log.debug(f"Shoveling {args.stdin_channel} to stdin")
        rd_channels[args.stdin_channel] = process.stdin
    if args.stdout_channel != None:
        log.debug(f"Shoveling stdout to {args.stdout_channel}")
        wr_channels[process.stdout] = args.stdout_channel
    if args.stderr_channel != None:
        log.debug(f"Shoveling stderr to {args.stderr_channel}")
        wr_channels[process.stderr] = args.stderr_channel

    log.info(f"Starting main shovel loop")
    shovel(client, wr_channels, rd_channels, lambda : process.poll() != None)

def do_server(args):
    log = toplevel_log.getChild("server")
    server = socket.socket()
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((args.host, args.port))
    server.listen(5)
    while True:
        client, address = server.accept()
        log.info(f"Accepted incomming connection from {address}")
        pid = os.fork()
        if pid == 0:
            try:
                if os.fork() == 0:
                    namespace_sandbox(args, handle_incomming_connection, args, client, address)
            except Exception as e:
                log.exception(f"Exception while handling connection: {e}")
            finally:
                sys.stderr.flush()
                sys.stdout.flush()
                os._exit(0)
        os.waitpid(pid, 0)
        client.close()

def handle_client(args, client):
    log = toplevel_log.getChild("client")

    do_pow_client(args, client)

    log.info("Opening TAP device")
    tap = open_tap_device(args.network_interface, address=args.network_address)

    log.info("Starting exploit process")
    process = subprocess.Popen(
        args.command,
        shell=args.shell,
        start_new_session=args.new_session,
        bufsize=0,
    )

    wr_channels = {tap: args.network_channel}
    rd_channels = {args.network_channel: tap}

    if args.stdin_channel != None:
        wr_channels[sys.stdin.buffer] = args.stdin_channel
    if args.stdout_channel != None:
        rd_channels[args.stdout_channel] = sys.stdout.buffer
    if args.stderr_channel != None:
        rd_channels[args.stderr_channel] = sys.stderr.buffer

    log.info(f"Starting main shovel loop")
    shovel(client, wr_channels, rd_channels, lambda : process.poll() != None)

def do_client(args):
    toplevel_log.info(f"Connecting to server {args.host} {args.port}")
    client = socket.socket()
    client.connect((args.host, args.port))

    namespace_sandbox(args, handle_client, args, client)

def parse_args():
    parser = argparse.ArgumentParser(description="Tool for easy network tunneling of ctf challenges. Builds a user/mount/pid/network sandbox with a isolated vpn interface for each connection")

    parser.add_argument("--log-level", dest="log_level", default=logging.WARN, type=int, help="Set log level (Default WARN)")
    parser.add_argument("--log-debug", dest="log_level", const=logging.DEBUG, action="store_const", help="Set log level to DEBUG")
    parser.add_argument("--log-info", dest="log_level", const=logging.INFO, action="store_const", help="Set log level to INFO")

    parser.add_argument("--unshare-user", dest="unshare_user", default=True, action="store_true", help="Unshare the user namespace, this allows for non-root operation (Default)")
    parser.add_argument("--no-unshare-user", dest="unshare_user", action="store_false", help="Do not unshare the user namespace")

    parser.add_argument("--network-channel", default=0xfffe, type=int, help="Change which channel to use for networking")
    parser.add_argument("--network-interface", default="eth0", type=str, help="Name of the vpn interface in the network namespace")
    parser.add_argument("--network-address", default=None, type=str, help="Address to configure on the vpn interface")

    parser.add_argument("--stdin-channel", default=None, type=int, help="Channel to tunnel stdin over, default disabled")
    parser.add_argument("--stdout-channel", default=1, type=int, help="Channel to tunnel stdout over")
    parser.add_argument("--stderr-channel", default=2, type=int, help="Channel to tunnel stderr over")

    parser.add_argument("--new-session", default=False, action="store_true", help="Start a new session when executing command(man 2 setsid)")
    parser.add_argument("--shell", default=False, action="store_true", help="Run the command as a shell script")

    subparsers = parser.add_subparsers(required=True)

    server_parser = subparsers.add_parser("server", help="Run ctfvpn in server mode")
    server_parser.set_defaults(func = do_server)

    server_parser.add_argument("--port", default=1337, type=int, help="Port to listen on")
    server_parser.add_argument("--host", default="0.0.0.0", help="address to listen on")

    server_parser.add_argument("--timeout", default=60, type=int, help="Timeout for solving challenge, after doing POW")

    server_parser.add_argument("--pow-timeout", default=60*60, type=int, help="Time for waiting for POW solution")
    server_parser.add_argument("--pow-bits", type=int, default=int(os.environ.get("POW_BITS", "24")), help="Bits of difficulty for POW(default: 24)")
    server_parser.add_argument("--pow-channel", type=int, default=0xffff, help="Channel to do POW on")

    server_parser.add_argument("command", nargs="+", help="Command to execute upon connection and successful POW")

    client_parser = subparsers.add_parser("client", help="Run ctfvpn in client mode")
    client_parser.set_defaults(func = do_client)

    client_parser.add_argument("--port", default=1337, type=int, help="which port to connect to")
    client_parser.add_argument("host", help="which host to connect to")

    client_parser.add_argument("command", nargs="+", help="Command to execute after connecting and successful POW")

    return parser.parse_args()

def main():
    args = parse_args()
    logging.basicConfig(level = args.log_level)
    toplevel_log.debug(f"Arguments: {args}")
    args.func(args)

if __name__ == "__main__": main()
