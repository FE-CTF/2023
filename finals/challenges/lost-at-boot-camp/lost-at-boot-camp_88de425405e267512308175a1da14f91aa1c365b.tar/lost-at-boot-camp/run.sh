#!/bin/bash

cd "$(dirname "$0")"
qemu-system-i386 -drive format=raw,file=boot_me.img
