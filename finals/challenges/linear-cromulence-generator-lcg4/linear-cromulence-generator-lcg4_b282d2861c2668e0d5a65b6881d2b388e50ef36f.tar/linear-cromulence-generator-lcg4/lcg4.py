#!/usr/bin/env python3

import sys
import lcg4_secret
import struct

from pathlib import Path
from lcglib import LCG, LCGCrypto

# See "Spectrally good multipliers for congruential pseudorandom number generators"
#
#   https://onlinelibrary.wiley.com/doi/10.1002/spe.3030
#
LCG_GOOD_MULTIPLIER_MOD32 = 0x915f77f5

if __name__ == "__main__":
    lcg = LCG(m=LCG_GOOD_MULTIPLIER_MOD32, s=lcg4_secret.state, c=0x1337)

    # TODO: optimize?
    for _ in range(0xdead1337beef):
        lcg.next()

    file = Path(sys.argv[1])
    cr = LCGCrypto(lcg, file.open("rb"))

    size = file.stat().st_size
    sys.stdout.buffer.write(cr.read(size))
