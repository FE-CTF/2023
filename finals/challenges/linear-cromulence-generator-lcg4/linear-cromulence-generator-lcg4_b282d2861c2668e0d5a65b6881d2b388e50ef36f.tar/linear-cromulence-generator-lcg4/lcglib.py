class LCG:
    """Linear Congruence Generator"""

    # Construct a new LCG instance
    #   m: multiplier
    #   c: addend
    #   s: initial state
    #   bits: output width, in bits
    #   shift: number of bits to truncate from internal state
    def __init__(self, m, c, s=0, bits=32, shift=0):
        self.m = m
        self.c = c
        self.bits = bits
        self.shift = shift
        self.mod = 1 << (bits + shift)
        self.state = s

    def next(self):
        self.state = ((self.state * self.m) + self.c) % self.mod
        return self.state >> self.shift

class LCGCrypto:
    """LCG Crypto adapter"""

    def __init__(self, lcg, fd):
        self.lcg = lcg
        self.fd = fd
        assert lcg.bits % 8 == 0, 'Uncromulent'

    #
    # Calculates number of "bs"-sized blocks needed to hold "nbytes" of data
    #
    @staticmethod
    def blocks(nbytes, bs):
        return (nbytes + bs - 1) // bs

    #
    # Read and encrypt "nbytes" number of bytes from fd
    #
    def read(self, nbytes):
        # Block size in bytes
        bs = self.lcg.bits // 8

        res = bytearray()
        for n in range(self.blocks(nbytes, bs)):
            data = self.fd.read(bs).ljust(bs, b'\0')
            a = int.from_bytes(data, byteorder='big')
            b = self.lcg.next()
            res.extend(int.to_bytes(a ^ b, length=bs, byteorder='big'))
        return res[:nbytes]
