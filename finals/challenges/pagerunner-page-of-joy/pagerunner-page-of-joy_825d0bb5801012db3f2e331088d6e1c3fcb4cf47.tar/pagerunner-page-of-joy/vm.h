#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <string.h>
#include <stdint.h>
#include <err.h>
#include <linux/kvm.h>
#include <sys/param.h>

#define exit_if(expr, str) if (expr) errx(EXIT_FAILURE, str);
#define exit_if_err(expr, str) exit_if((expr) < 0, str)

struct vm {
	int sys_fd;
	int fd;
	char *mem;
	uint64_t mem_size;
};

struct vcpu {
	int fd;
	struct kvm_run *kvm_run;
};

void vm_init(struct vm *vm);
void vcpu_init(struct vm *vm, struct vcpu *vcpu);
void alloc_memory(struct vm *vm, uint64_t mem_size);
