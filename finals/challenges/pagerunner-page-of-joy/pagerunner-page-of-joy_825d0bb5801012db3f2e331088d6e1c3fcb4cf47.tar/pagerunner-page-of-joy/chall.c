#include "vm.h"

#define MAX_FLAG_LEN 0x100
char flag[MAX_FLAG_LEN];

struct guest_request {
	char req[0x100];
	char resp[MAX_FLAG_LEN];
};

#define REQUEST_ADDRESS 0x1000
#define REQUEST_STRING "Flag please!"
#define PORT_COM1 0x3f8

char as_hex(char c)
{
    if ('0' <= c && c <= '9') { return c - '0'; }
    if ('a' <= c && c <= 'f') { return c + 10 - 'a'; }
    if ('A' <= c && c <= 'F') { return c + 10 - 'A'; }
    errx(EXIT_FAILURE, "Input char not hexdigit");
}

void load_user_code(struct vm *vm)
{
	printf("Please provide hex-encoded x86 machine code\n");
	fflush(stdout);

	char hex[0x2000];
	memset(hex, 0, 0x2000);

	exit_if_err(read(STDIN_FILENO, hex, 0x2000), "read() failed");

	int hexcnt = 0;
	while (isxdigit(hex[hexcnt])) hexcnt++;

	exit_if(hexcnt % 2 == 1, "Expected even amount of bytes");
	for (int i = 0; i < hexcnt; i = i + 2) {
		vm->mem[i/2] = as_hex(hex[i]) * 0x10 + as_hex(hex[i+1]);
	}
}

void handle_io(struct vcpu *vcpu)
{
	exit_if(vcpu->kvm_run->io.direction != KVM_EXIT_IO_OUT, "Expected OUT instruction");
	exit_if(vcpu->kvm_run->io.port != PORT_COM1, "Did not write to serial console");

	char *p = (char *)vcpu->kvm_run;
	write(STDOUT_FILENO, p + vcpu->kvm_run->io.data_offset, vcpu->kvm_run->io.size);
}

void handle_mmio(struct vm *vm, struct vcpu *vcpu)
{
	exit_if(!vcpu->kvm_run->mmio.is_write, "Not write")

	uint64_t addr = vcpu->kvm_run->mmio.phys_addr;
	exit_if(addr != REQUEST_ADDRESS, "Unknown addr")

	uint64_t value = 0;
	memcpy(&value, vcpu->kvm_run->mmio.data, MIN(sizeof(value), vcpu->kvm_run->mmio.len));

	exit_if(value > vm->mem_size - sizeof(struct guest_request), "Not mapped")

	struct guest_request *io = (struct guest_request *) (vm->mem + value);

	exit_if(strncmp(io->req, REQUEST_STRING, sizeof(io->req)), "Unknown request")
	memcpy(io->resp, flag, sizeof(io->resp));
}

int run_vm(struct vm *vm, struct vcpu *vcpu)
{
	struct kvm_regs regs;
	uint64_t memval = 0;

	for (;;) {
		exit_if_err(ioctl(vcpu->fd, KVM_RUN, 0), "KVM_RUN");

		switch (vcpu->kvm_run->exit_reason) {
		case KVM_EXIT_HLT:
			return 0;

		case KVM_EXIT_IO:
			handle_io(vcpu);
			continue;

		case KVM_EXIT_MMIO:
			handle_mmio(vm, vcpu);
			continue;

		default:
			errx(EXIT_FAILURE, "Error while handling exit_reason %d", vcpu->kvm_run->exit_reason);
		}
	}

	return 1;
}

void load_flag()
{
	memset(flag, 0, MAX_FLAG_LEN);
	int fd = open("flag", O_RDONLY);
	exit_if(fd < 0, "Could not open flag");
	int res = read(fd, flag, MAX_FLAG_LEN - 1);
	exit_if(res <= 0 || res == MAX_FLAG_LEN - 1, "read()");
}

int main(int argc, char **argv)
{
	struct vm vm;
	struct vcpu vcpu;

	load_flag();

	vm_init(&vm);
	alloc_memory(&vm, 0x1000);
	vcpu_init(&vm, &vcpu);
	load_user_code(&vm);

	alarm(1);
	return run_vm(&vm, &vcpu);
}
