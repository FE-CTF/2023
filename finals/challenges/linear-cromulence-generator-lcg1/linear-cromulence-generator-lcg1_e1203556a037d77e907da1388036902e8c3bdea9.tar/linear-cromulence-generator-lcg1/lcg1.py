#!/usr/bin/env python3

import sys
import lcg1_secret
from pathlib import Path
from lcglib import LCG, LCGCrypto

if __name__ == "__main__":
    lcg = LCG(m=0xdeadbeef, c=lcg1_secret.increment)
    file = Path(sys.argv[1])
    cr = LCGCrypto(lcg, file.open("rb"))

    size = file.stat().st_size
    sys.stdout.buffer.write(cr.read(size))
