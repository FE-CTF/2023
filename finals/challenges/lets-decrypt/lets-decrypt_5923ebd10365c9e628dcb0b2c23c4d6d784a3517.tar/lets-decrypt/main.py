#!/usr/bin/env -S python3 -u
import os
import random
import string
from base64 import b64decode, b64encode

IV_LEN = 4

def init(K):
    global S, i, j
    S = bytearray(range(0x100))
    j = 0
    for i in range(0x100):
        j = (j + S[i] + K[i % len(K)]) & 0xff
        S[i], S[j] = S[j], S[i]
    i, j = 0, 0

def stream():
    global i, j
    i = (i + 1) & 0xff
    j = (j + S[i]) & 0xff
    S[i], S[j] = S[j], S[i]
    return S[(S[i] + S[j]) & 0xff]

def enc(K, pt):
    iv = os.urandom(IV_LEN)
    ct = bytearray([IV_LEN]) + iv
    init(K + iv)
    for c in pt:
        ct.append(c ^ stream())
    return bytes(ct)

def dec(K, ct):
    if not ct:
        raise ValueError
    ivlen = ct[0]
    iv = ct[1 : 1 + ivlen]
    if len(iv) < ivlen:
        raise ValueError
    init(K + iv)
    pt = bytearray()
    for c in ct[1 + ivlen:]:
        pt.append(c ^ stream())
    return bytes(pt)

if __name__ == '__main__':
    K = open('secret_key', 'rb').readline().strip()
    MAX_LEN = 300
    CH_LEN = 50
    while True:
        print('Menu:')
        print('f) Get flag')
        print('d) Decrypt')
        print('x) Exit')
        s = input('> ')
        if s == 'f':
            pt = ''
            for _ in range(CH_LEN):
                pt += random.choice(string.ascii_letters)
            print(f'Please encrypt "{pt}"')
            ct = b64decode(input('b64> '))
            if pt.encode() == dec(K, ct):
                print(open('flag', 'r').readline().strip())
            break
        elif s == 'd':
            ct = b64decode(input('b64> '))
            if len(ct) > MAX_LEN:
                print('Ciphertext too long')
                break
            pt = dec(K, ct)
            print(b64encode(pt).decode())
        elif s == 'x':
            break
