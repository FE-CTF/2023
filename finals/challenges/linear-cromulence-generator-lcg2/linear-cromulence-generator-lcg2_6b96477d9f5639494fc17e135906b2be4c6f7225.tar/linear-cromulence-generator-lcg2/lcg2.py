#!/usr/bin/env python3

import sys
import lcg2_secret
from pathlib import Path
from lcglib import LCG, LCGCrypto

if __name__ == "__main__":
    lcg = LCG(m=0xdeadbeef, s=lcg2_secret.state, c=0x1337)

    file = Path(sys.argv[1])
    cr = LCGCrypto(lcg, file.open("rb"))

    size = file.stat().st_size
    sys.stdout.buffer.write(cr.read(size))
