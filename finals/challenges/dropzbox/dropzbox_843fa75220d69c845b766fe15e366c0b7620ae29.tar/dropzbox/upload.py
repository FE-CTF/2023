#!/usr/bin/env python3
import socket
import sys
import zlib

if len(sys.argv) not in (4, 5):
    print('usage: %s <host> <port> <name> [<path>]' % sys.argv[0],
          file=sys.stderr)
    sys.exit(1)

host = sys.argv[1]
port = int(sys.argv[2])
name = sys.argv[3]

ifd = sys.stdin if len(sys.argv) == 4 else open(sys.argv[4], 'r')
data = ifd.read().encode('utf')

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((host, port))

def send(data):
    i = 0
    while i < len(data):
        n = sock.send(data[i:])
        if n == 0:
            print('Lost connection', file=sys.stderr)
            sys.exit(1)
        i += n

send(b'1\n')
send(name.encode('utf8') + b'\n')
send(zlib.compress(data))
sock.close()
