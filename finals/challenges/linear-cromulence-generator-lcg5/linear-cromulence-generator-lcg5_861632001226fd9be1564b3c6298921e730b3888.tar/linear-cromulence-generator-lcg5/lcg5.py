#!/usr/bin/env python3

import sys
import asn1
import lcg5_secret
from hashlib import sha1
from pathlib import Path
from lcglib import LCG, LCGCrypto

if __name__ == "__main__":
    file = Path(sys.argv[1])
    encoder = asn1.Encoder()
    encoder.start()
    with encoder.construct(asn1.Numbers.Sequence):
        with encoder.construct(asn1.Numbers.Sequence):
            encoder.write('version')
            encoder.write('1.0.0', asn1.Numbers.ObjectIdentifier)
        with encoder.construct(asn1.Numbers.Sequence):
            encoder.write('payload')
            encoder.write(file.read_bytes())
        with encoder.construct(asn1.Numbers.Sequence):
            encoder.write('checksum')
            encoder.write(sha1(file.read_bytes()).digest())
    data = encoder.output()
    size = len(data)
    bits = size * 8
    shift = 80
    s = int.from_bytes(data, byteorder='big')
    lcg = LCG(s=s, m=lcg5_secret.multiplier, c=lcg5_secret.increment, bits=bits, shift=shift)
    cr = LCGCrypto(lcg, open("/dev/zero", "rb"))

    sys.stdout.buffer.write(cr.read(size))
