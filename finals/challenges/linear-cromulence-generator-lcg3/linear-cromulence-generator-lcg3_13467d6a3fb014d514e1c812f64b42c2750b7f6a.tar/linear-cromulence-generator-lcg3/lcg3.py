#!/usr/bin/env python3

import sys
import lcg3_secret
import struct

from pathlib import Path
from lcglib import LCG, LCGCrypto

# See "Spectrally good multipliers for congruential pseudorandom number generators"
#
#   https://onlinelibrary.wiley.com/doi/10.1002/spe.3030
#
LCG_GOOD_MULTIPLIER_MOD32 = 0x915f77f5

if __name__ == "__main__":
    lcg = LCG(m=LCG_GOOD_MULTIPLIER_MOD32, s=lcg3_secret.state, c=0x1337)

    # better initialize the rng this time
    for _ in range(42):
        lcg.next()

    file = Path(sys.argv[1])
    cr = LCGCrypto(lcg, file.open("rb"))

    size = file.stat().st_size
    sys.stdout.buffer.write(cr.read(size))

    # append state as checksum
    sys.stdout.buffer.write(struct.pack(">I", cr.lcg.state))
