#!/usr/bin/env -S python3 -u
import os
import random
import string
from base64 import b64decode, b64encode

IV_LEN = 4

def init(K):
    global S, i, j
    S = bytearray(range(0x100))
    j = 0
    for i in range(0x100):
        j = (j + S[i] + K[i % len(K)]) & 0xff
        S[i], S[j] = S[j], S[i]
    i, j = 0, 0

def stream():
    global i, j
    i = (i + 1) & 0xff
    j = (j + S[i]) & 0xff
    S[i], S[j] = S[j], S[i]
    return S[(S[i] + S[j]) & 0xff]

def enc(K, pt):
    iv = os.urandom(IV_LEN)
    ct = bytearray([IV_LEN]) + iv
    init(K + iv)
    for c in pt:
        ct.append(c ^ stream())
    return bytes(ct)

def dec(K, ct):
    if not ct:
        raise ValueError
    ivlen = ct[0]
    iv = ct[1 : 1 + ivlen]
    if len(iv) < ivlen:
        raise ValueError
    init(K + iv)
    pt = bytearray()
    for c in ct[1 + ivlen:]:
        pt.append(c ^ stream())
    return bytes(pt)

if __name__ == '__main__':
    K = open('secret_key', 'rb').readline().strip()
    CH_LEN = 50
    while True:
        print('Menu:')
        print('f) Get flag')
        print('e) Encrypt')
        print('x) Exit')
        s = input('> ')
        if s == 'f':
            pt = ''
            for _ in range(CH_LEN):
                pt += random.choice(string.ascii_letters)
            ct = enc(K, pt.encode())
            b64ct = b64encode(ct).decode()
            print(f'Please decrypt "{b64ct}"')
            pt2 = input('> ')
            if pt == pt2:
                print(open('flag', 'r').readline().strip())
            break
        elif s == 'e':
            pt = b64decode(input('b64> '))
            ct = enc(K, pt)
            print(b64encode(ct).decode())
        elif s == 'x':
            break
