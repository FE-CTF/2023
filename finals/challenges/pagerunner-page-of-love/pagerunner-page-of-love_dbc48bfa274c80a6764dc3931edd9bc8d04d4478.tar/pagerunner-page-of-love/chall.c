#include "vm.h"

#define RINGBUF_MSG_LEN 0x100
#define RINGBUF_MSG_BUF_LEN (0x100 - 0x8)

char as_hex(char c)
{
    if ('0' <= c && c <= '9') { return c - '0'; }
    if ('a' <= c && c <= 'f') { return c + 10 - 'a'; }
    if ('A' <= c && c <= 'F') { return c + 10 - 'A'; }
    errx(EXIT_FAILURE, "Input char not hexdigit");
}

void load_user_code(struct vm *vm)
{
	printf("Please provide hex-encoded x86 machine code\n");
	fflush(stdout);

	char hex[0x2000];
	memset(hex, 0, 0x2000);

	exit_if_err(read(STDIN_FILENO, hex, 0x2000), "read() failed");

	int hexcnt = 0;
	while (isxdigit(hex[hexcnt])) hexcnt++;

	exit_if(hexcnt % 2 == 1, "Expected even amount of bytes");
	for (int i = 0; i < hexcnt; i = i + 2) {
		vm->mem[i/2] = as_hex(hex[i]) * 0x10 + as_hex(hex[i+1]);
	}
}

void run_vm(struct vm *vm, struct vcpu *vcpu)
{
	struct kvm_regs regs;

	for (;;) {
		exit_if_err(ioctl(vcpu->fd, KVM_RUN, 0), "KVM_RUN");

		switch (vcpu->kvm_run->exit_reason) {
		case KVM_EXIT_HLT:
			return;

		default:
			errx(EXIT_FAILURE, "Error while handling exit_reason %d", vcpu->kvm_run->exit_reason);
		}
	}
}

enum {
	RB_INACTIVE,
	RB_STARTING,
	RB_ACTIVE,
};

enum {
	RB_MSG_EMPTY,
	RB_MSG_CONTENT,
};

typedef struct _ringbuf ringbuf;

typedef struct _ringbuf_msg {
	uint32_t state;
	uint32_t len;
	uint8_t buf[RINGBUF_MSG_BUF_LEN];
} ringbuf_msg;

typedef int (* rb_fn_rxtx_t)(ringbuf *, uint8_t *, uint32_t);
typedef ringbuf_msg * (* rb_fn_msg_t)(uint64_t, uint32_t, uint32_t);

typedef struct _ringbuf_ops {
	rb_fn_rxtx_t tx;
	rb_fn_rxtx_t rx;
	rb_fn_msg_t tomsg;
} ringbuf_ops;

typedef struct _ringbuf {
	uint64_t base;
	uint64_t state;
	uint64_t tx_start;
	uint64_t tx_size;
	uint64_t rx_start;
	uint64_t rx_size;
	uint32_t tx_seq;
	uint32_t tx_ack;
	uint32_t rx_seq;
	uint32_t rx_ack;
	ringbuf_ops host_ops;
	ringbuf_ops guest_ops;
} ringbuf;

ringbuf_msg *ringbuf_tomsg(uint64_t area, uint32_t index, uint32_t area_size)
{
	return (ringbuf_msg *) (area + RINGBUF_MSG_LEN * (index % (area_size / RINGBUF_MSG_LEN)));
}

int ringbuf_write(ringbuf *rb, uint8_t *buf, uint32_t bufsz)
{
	if (rb->state != RB_ACTIVE) return 0;

	ringbuf_msg *msg = rb->host_ops.tomsg(rb->base + rb->tx_start, rb->tx_seq, rb->tx_size);
	if (!msg || msg->state != RB_MSG_EMPTY) return 0;

	msg->state == RB_MSG_CONTENT;
	msg->len = MIN(bufsz, RINGBUF_MSG_BUF_LEN);
	memcpy(msg->buf, buf, msg->len);
	rb->tx_seq++;
	return msg->len;
}

int ringbuf_read(ringbuf *rb, uint8_t *buf, uint32_t bufsz)
{
	if (rb->state != RB_ACTIVE) return 0;
	if (rb->rx_seq == rb->rx_ack) return 0;

	ringbuf_msg *msg = rb->host_ops.tomsg(rb->base + rb->rx_start, rb->rx_ack, rb->rx_size);
	rb->rx_ack++;

	if (!msg || msg->state == RB_MSG_EMPTY) return 0;

	msg->state == RB_MSG_EMPTY;
	bufsz = MIN(bufsz, msg->len);
	memcpy(buf, msg->buf, bufsz);
	return bufsz;
}

int ringbuf_init(ringbuf *rb)
{
	rb->base = (uint64_t) rb;
	rb->state = RB_STARTING;
	rb->tx_start = 0x200;
	rb->tx_size = 0x700;
	rb->rx_start = 0x900;
	rb->rx_size = 0x700;
	rb->tx_seq = 0;
	rb->tx_ack = 0;
	rb->rx_seq = 0;
	rb->rx_ack = 0;
	rb->host_ops = (ringbuf_ops) {
		.tx = ringbuf_write,
		.rx = ringbuf_read,
		.tomsg = ringbuf_tomsg,
	};
	rb->guest_ops = (ringbuf_ops) {
		.tx = NULL,
		.rx = NULL,
		.tomsg = NULL,
	};
	return 0;
}

void *echo_service (void *ptr)
{
	ringbuf *rb = (ringbuf *) ptr;
	uint8_t buf[RINGBUF_MSG_BUF_LEN];

	while (rb->state != RB_INACTIVE) {
		uint32_t len = rb->host_ops.rx(rb, buf, sizeof(buf));
		if (len) {
			rb->host_ops.tx(rb, buf, len);
		}
		usleep(100000);
	}
	return NULL;
}

int main(int argc, char **argv)
{
	pthread_t thread_id;
	struct vm vm;
	struct vcpu vcpu;

	vm_init(&vm);
	alloc_memory(&vm, 0x10000);
	vcpu_init(&vm, &vcpu);
	load_user_code(&vm);

	ringbuf *rb = (ringbuf *) &vm.mem[0x1000];
	ringbuf_init(rb);
	pthread_create(&thread_id, NULL, echo_service, rb);

	alarm(5);
	run_vm(&vm, &vcpu);
	pthread_join(thread_id, NULL);
	return 0;
}
