#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <string.h>
#include <stdint.h>
#include <err.h>
#include <linux/kvm.h>
#include <sys/param.h>
#include <pthread.h>

/* CR0 bits */
#define CR0_PE 1u
#define CR0_MP (1U << 1)
#define CR0_EM (1U << 2)
#define CR0_TS (1U << 3)
#define CR0_ET (1U << 4)
#define CR0_NE (1U << 5)
#define CR0_WP (1U << 16)
#define CR0_AM (1U << 18)
#define CR0_NW (1U << 29)
#define CR0_CD (1U << 30)
#define CR0_PG (1U << 31)

#define CR4_PAE (1U << 5)

#define PDE64_PRESENT 1
#define PDE64_RW (1U << 1)
#define PDE64_USER (1U << 2)
#define PDE64_ACCESSED (1U << 5)
#define PDE64_DIRTY (1U << 6)
#define PDE64_PS (1U << 7)
#define PDE64_G (1U << 8)

#define EFER_SCE 1
#define EFER_LME (1U << 8)
#define EFER_LMA (1U << 10)
#define EFER_NXE (1U << 11)

#define exit_if(expr, str) if (expr) errx(EXIT_FAILURE, str);
#define exit_if_err(expr, str) exit_if((expr) < 0, str)

struct vm {
	int sys_fd;
	int fd;
	char *mem;
	uint64_t mem_size;
};

struct vcpu {
	int fd;
	struct kvm_run *kvm_run;
};

void vm_init(struct vm *vm);
void vcpu_init(struct vm *vm, struct vcpu *vcpu);
void alloc_memory(struct vm *vm, uint64_t mem_size);
