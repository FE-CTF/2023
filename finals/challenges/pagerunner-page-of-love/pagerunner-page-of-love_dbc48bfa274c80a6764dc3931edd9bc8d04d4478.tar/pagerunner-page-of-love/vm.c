#include "vm.h"

void vm_init(struct vm *vm)
{
	exit_if_err(vm->sys_fd = open("/dev/kvm", O_RDWR), "could not open /dev/kvm");

	int api_ver;
	exit_if_err(api_ver = ioctl(vm->sys_fd, KVM_GET_API_VERSION, 0), "KVM_GET_API_VERSION");
	exit_if(api_ver != KVM_API_VERSION, "KVM_API version");

	exit_if_err(vm->fd = ioctl(vm->sys_fd, KVM_CREATE_VM, 0), "KVM_CREATE_VM");
}

void setup_long_mode(struct vm *vm, struct kvm_sregs *sregs)
{
	exit_if(vm->mem_size < 0x5000, "Too little memory allocated");
	uint64_t pml4_addr = 0x2000;
	uint64_t *pml4 = (void *)(vm->mem + pml4_addr);

	uint64_t pdpt_addr = 0x3000;
	uint64_t *pdpt = (void *)(vm->mem + pdpt_addr);

	uint64_t pd_addr = 0x4000;
	uint64_t *pd = (void *)(vm->mem + pd_addr);

	pml4[0] = PDE64_PRESENT | PDE64_RW | pdpt_addr;
	pdpt[0] = PDE64_PRESENT | PDE64_RW | pd_addr;
	pd[0] = PDE64_PRESENT | PDE64_RW | PDE64_PS;

	sregs->cr3 = pml4_addr;
	sregs->cr4 |= CR4_PAE;
	sregs->cr0 |= CR0_PE | CR0_PG;
	sregs->efer |= EFER_LME | EFER_LMA;

	struct kvm_segment seg = {
		.base = 0,
		.limit = 0xffffffff,
		.selector = 1 << 3,
		.present = 1,
		.type = 11,
		.dpl = 0,
		.db = 0,
		.s = 1,
		.l = 1,
		.g = 1,
	};

	sregs->cs = seg;

	seg.type = 3;
	seg.selector = 2 << 3;
	sregs->ds = sregs->es = sregs->fs = sregs->gs = sregs->ss = seg;
}

void vcpu_init(struct vm *vm, struct vcpu *vcpu)
{
	int vcpu_mmap_size;

	vcpu->fd = ioctl(vm->fd, KVM_CREATE_VCPU, 0);
	exit_if_err(vcpu->fd, "KVM_CREATE_VCPU");

	vcpu_mmap_size = ioctl(vm->sys_fd, KVM_GET_VCPU_MMAP_SIZE, 0);
	exit_if(vcpu_mmap_size <= 0, "KVM_GET_VCPU_MMAP_SIZE");

	vcpu->kvm_run = mmap(NULL, vcpu_mmap_size, PROT_READ | PROT_WRITE, MAP_SHARED, vcpu->fd, 0);
	exit_if(vcpu->kvm_run == MAP_FAILED, "mmap kvm_run");

	struct kvm_sregs sregs;
	exit_if_err(ioctl(vcpu->fd, KVM_GET_SREGS, &sregs), "KVM_GET_SREGS");

	setup_long_mode(vm, &sregs);

	exit_if_err(ioctl(vcpu->fd, KVM_SET_SREGS, &sregs), "KVM_SET_SREGS");

	struct kvm_regs regs;
	memset(&regs, 0, sizeof(regs));
	regs.rflags = 2;
	regs.rip = 0;

	exit_if_err(ioctl(vcpu->fd, KVM_SET_REGS, &regs), "KVM_SET_REGS");
}

void alloc_memory(struct vm *vm, uint64_t mem_size)
{
	void *mem = mmap(NULL, mem_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);

	exit_if(mem == MAP_FAILED, "mmap failed");

	struct kvm_userspace_memory_region memreg = {
		.slot = 0,
		.flags = 0,
		.guest_phys_addr = 0,
		.memory_size = mem_size,
		.userspace_addr = (long) mem,
	};
	exit_if_err(ioctl(vm->fd, KVM_SET_USER_MEMORY_REGION, &memreg), "KVM_SET_USER_MEMORY_REGION");

	vm->mem = mem;
	vm->mem_size = mem_size;
}
