#!/usr/bin/env python3
import random
import signal
random = random.SystemRandom()

ROUNDS = 666
BOXES = 32

def getPermutation():
    perm = list(range(BOXES))
    for _ in range(666):
        while True:
            a = random.randrange(0, BOXES)
            b = random.randrange(0, BOXES)
            if a != b:
                break
        perm[a], perm[b] = perm[b], perm[a]
    return perm

if __name__ == "__main__":
    signal.alarm(1200)
    print('Welcome to Mission: Possible')
    for r in range(ROUNDS):
        print(f'Round #{r}')
        needle = random.randrange(0, BOXES)
        haystack = getPermutation()
        print(f'Find the box with {needle} in it.')
        for _ in range(BOXES - 1):
            try:
                i = int(input('Which box do you want to open? '))
                j = haystack[i]
            except:
                print('wat')
                exit(1)
            if j == needle:
                print(f'Correct.  Found {j} in box {i}.')
                break
            else:
                print(f'Wrong.  Found {j} in box {i}.')
        else:
            print('Mission failed')
            exit(1)

    print('Mission accomplished')
    with open('/flag') as fd:
        print(fd.read().strip())
