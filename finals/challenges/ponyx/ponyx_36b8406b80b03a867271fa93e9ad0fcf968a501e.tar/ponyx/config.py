import os

class Config:
    BASEURL = "http://localhost:5000/"