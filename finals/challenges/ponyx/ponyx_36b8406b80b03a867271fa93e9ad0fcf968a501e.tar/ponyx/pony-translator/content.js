console.log("Pony Twitter Translator Extension");
console.log("[EXT] Hi from content.js!");

function translateNode(author, node) {
  // Message passing
  chrome.runtime.sendMessage({ type: "translation-request", data: { author: author, text: node.textContent } }, (response) => {
    if (!response) {
      if (chrome.runtime.lastError) {
        console.log("Error occured:", chrome.runtime.lastError);
      }
    }
    else if (response.type === "translation-response"){
      node.textContent = response.data.text;
    }
    else {
      console.log(response);
    }
  })
}

// Grab all post nodes
var posts = document.querySelectorAll("div.post");
posts.forEach(post => {
  // Extract information and translate
  const author = post.querySelector("p.author").textContent;
  const contentNode = post.querySelector("p.content");
  translateNode(author, contentNode);
});