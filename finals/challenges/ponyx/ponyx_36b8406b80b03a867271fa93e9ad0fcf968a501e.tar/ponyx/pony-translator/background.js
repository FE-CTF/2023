console.log("Pony Twitter Translator Extension");
console.log("[EXT] Hi from background.js!");

const translation_keys = {
  "bee-pony": new UtfString("zb"),
  "demon-pony": new UtfString("6бᏮⳒ６𑣕𝟔𝟞𝟨𝟲𝟼🯶"),
  "eldritch-pony": new UtfString("𒅋𒆴𒈙𒉛"),
  "magnus-pony": new UtfString("🨀🨁🨂🨃🨄🨅")
}

function translate(key, text) {
  let words = text.split(" ");
  let base = key.length;
  let result = '';
  words.forEach(word => {
    // Start by converting each letter to corresponding base representation
    let encoded = '';
    let utf_word = new UtfString(word);
    utf_word.split('').forEach(letter => {
      let index = key.indexOf(letter);
      encoded += index.toString(base);
    });
    // Encoded now holds base-len-encoded index of word in dict
    let index = parseInt(encoded, base);
    result += english_words[index] + " ";
  });
  return result.trim();
}
// Message passing
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log(sender, message);
  if (message.type === "translation-request") {
    if (message.data.author in translation_keys) {
      sendResponse({
        type: "translation-response",
        data: {
          text: translate(translation_keys[message.data.author], message.data.text)
        }
      })
    }
    else if (message.data.author === "robot-pony") {
      sendResponse({ type: "translation-response", data: { text: eval(message.data.text) } });
    }
    else {
      sendResponse({ type: "error", data: { text: "no author found with that name" } });
    }
  }
});