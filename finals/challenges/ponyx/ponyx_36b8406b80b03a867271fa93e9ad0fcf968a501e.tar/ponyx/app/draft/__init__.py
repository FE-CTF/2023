from quart import Blueprint

bp = Blueprint('draft', __name__)

from app.draft import routes