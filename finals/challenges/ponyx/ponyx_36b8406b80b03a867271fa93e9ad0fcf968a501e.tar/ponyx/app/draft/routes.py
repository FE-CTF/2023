from quart import render_template
from app.draft import bp

@bp.route('/edit')
async def edit():
    return await render_template('draft/edit.html')

@bp.route('/preview')
async def preview():
    return await render_template('draft/preview.html')