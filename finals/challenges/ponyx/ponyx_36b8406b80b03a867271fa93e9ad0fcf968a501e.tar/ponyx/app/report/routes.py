from quart import render_template, current_app
from app.report import bp

@bp.route('/')
async def index():
    return await render_template('report/index.html', baseurl=current_app.config["BASEURL"])