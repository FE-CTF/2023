// Needs to be at top of body to trigger before rendering starts
document.getAnimations()[0].currentTime = new Date().getTime();