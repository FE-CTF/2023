from quart import Blueprint

bp = Blueprint('bot', __name__)

from app.bot import routes