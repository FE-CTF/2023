from quart import render_template, request
from app.bot import bp
import os
import asyncio
from playwright.async_api import async_playwright, Playwright, TimeoutError as PlaywrightTimeoutError

parent_dir_path = os.path.dirname(os.path.realpath(__file__))
path_to_extension = "./pony-translator"

@bp.route('/visit', methods = ['POST'])
async def visit():
    url = (await request.form).get('url')
    hostname = "localhost:5000"
    if not url.startswith(f"http://{hostname}/"):
        return f"Bad URL, must start with http://{hostname}/", 400 
    print(f"Visiting url: {url}")
    async with async_playwright() as playwright:
        err = await run(playwright, url)
    if err: return err
    return "Successfully visited"

async def run(playwright: Playwright, url: str):
    chromium = playwright.chromium # or "firefox" or "webkit".
    context = await chromium.launch_persistent_context(
        "",
        args=[
            "--headless=new", #https://playwright.dev/python/docs/chrome-extensions#headless-mode
            f"--disable-extensions-except={path_to_extension}",
            f"--load-extension={path_to_extension}",
        ]
    )
    if len(context.background_pages) == 0:
        background_page = await context.wait_for_event('backgroundpage')
    else:
        background_page = context.background_pages[0]
    background_page.on("console", lambda msg: print("[EXT-Debug]", msg.text, flush=True))

    page = await context.new_page()
    # Wouldn't want this being read, now would we?
    await page.goto(f'file://{parent_dir_path}/flag.txt')

    # Visit reported page
    page = await context.new_page()
    try:
        await page.goto(url, timeout=3000, wait_until='networkidle')
    except PlaywrightTimeoutError:
        await context.close()
        return "Navigation timed out", 500
    
    await context.close()