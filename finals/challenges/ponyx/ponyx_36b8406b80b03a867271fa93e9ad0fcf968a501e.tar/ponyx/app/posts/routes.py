from quart import render_template
from app.posts import bp

@bp.route('/')
async def index():
    return await render_template('posts/index.html')