from quart import Quart
from config import Config

app = Quart(__name__)
app.config.from_object(Config)

from app.main import bp as main_bp
app.register_blueprint(main_bp)

from app.posts import bp as posts_bp
app.register_blueprint(posts_bp, url_prefix='/posts')

from app.draft import bp as draft_bp
app.register_blueprint(draft_bp, url_prefix='/draft')

from app.report import bp as report_bp
app.register_blueprint(report_bp, url_prefix='/report')

from app.bot import bp as bot_bp
app.register_blueprint(bot_bp, url_prefix='/bot')