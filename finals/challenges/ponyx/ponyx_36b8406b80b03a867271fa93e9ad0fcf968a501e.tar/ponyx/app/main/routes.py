from quart import render_template
from app.main import bp

@bp.route('/')
async def index():
    return await render_template('index.html')